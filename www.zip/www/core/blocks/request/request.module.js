;(function () {
    'use strict';

    angular.module('app.request', [
        'factory.url',
        'factory.request'
    ]);

})();